package org.cap.assignmentsio;

import java.util.Scanner;

public class StudentDetails {
	int regno;
	String name;
	double feeamount;
	String gender;
	int mark1;
	int mark2;
	int mark3;
	Scanner s1=new Scanner(System.in);
	public void getStudent()
	{
		System.out.println("Enter regno");
		regno=s1.nextInt();
		System.out.println("Enter name");
		name=s1.next();
		System.out.println("Enter fee amount");
		feeamount=s1.nextDouble();
		System.out.println("Enter gender");
		gender=s1.next();
		System.out.println("Enter mark in c");
		mark1=s1.nextInt();
		System.out.println("Enter mark in c++");
		mark2=s1.nextInt();
		System.out.println("Enter mark in java");
		mark3=s1.nextInt();
		
	}
	

}
