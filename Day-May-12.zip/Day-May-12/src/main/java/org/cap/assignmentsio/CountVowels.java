package org.cap.assignmentsio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

import java.io.IOException;

public class CountVowels {
	public static void main(String[] args) {

		File file = new File("D:\\MyJava\\Workspace\\Day-May-12\\src\\main\\resources\\sourcefile.txt");

		FileReader fileReader = null;

		String str = "";

		try {
			fileReader = new FileReader(file);

			long fsize = file.length();
			while (fsize > 0) {
				int ch = fileReader.read();
				str += (char) ch;
				fsize--;
			}

			System.out.println(str);
			
			char[] ch=str.toCharArray();
			int count_a=0,count_e=0,count_i=0,count_o=0,count_u=0;
			
			for (int i = 0; i < ch.length; i++) {
				if(ch[i]=='a'||ch[i]=='A')
				{
				count_a++;
				}
				if(ch[i]=='e'||ch[i]=='E')
				{
				count_e++;
				}
				if(ch[i]=='i'||ch[i]=='I')
				{
				count_i++;
				}
				if(ch[i]=='o'||ch[i]=='O')
				{
				count_o++;
				}
				if(ch[i]=='u'||ch[i]=='U')
				{
				count_u++;
				}
				
				
			}
			
			System.out.println(count_a+" "+count_e+" "+count_i+" "+count_o+" "+count_u);
			

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		finally {
			try {
				fileReader.close();

			} catch (IOException e) {

				e.printStackTrace();
			}

		}

	}

}
