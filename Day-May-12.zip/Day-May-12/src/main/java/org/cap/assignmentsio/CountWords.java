package org.cap.assignmentsio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CountWords {
	public static void main(String[] args) {
		File file = new File("D:\\MyJava\\Workspace\\Day-May-12\\src\\main\\resources\\count.txt");
		FileReader fileReader = null;
		String str = "";

		try {
			fileReader = new FileReader(file);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		}

		long fsize = file.length();

		try {
			while (fsize > 0) {

				int ch = fileReader.read();

				str += (char) ch;
				fsize--;
			}
			System.out.println(str);
			int count=1;
			int linecount=1;
			char[] ch=str.toCharArray();
			for (int i = 0; i <ch.length; i++) {
				if(ch[i]==' ' &&ch[i+1]!=' ')
				{
					count++;
				}
				if(ch[i]=='\n')
				{
					linecount++;
				}
				
			}
			System.out.println("no of words:"+count);
			System.out.println("no of lines:"+linecount);
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}

	}
}
