package org.cap.assignmentsio;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class Main_Student {

	public static void main(String[] args) {
//To write data into file
		StudentDetails st = new StudentDetails();
		st.getStudent();
		File file = new File("D:\\MyJava\\Workspace\\Day-May-12\\src\\main\\resources\\student.txt");
		FileOutputStream fout = null;
		DataOutputStream dout = null;

		try {
			fout = new FileOutputStream(file);
			dout = new DataOutputStream(fout);

			dout.writeInt(st.regno);
			dout.writeInt(st.mark1);
			dout.writeInt(st.mark2);
			dout.writeInt(st.mark3);
			dout.writeDouble(st.feeamount);
			dout.write(st.gender.getBytes());
			dout.write(st.name.getBytes());

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		} finally {
			try {
				dout.close();
				fout.close();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
		// To read data from student.txt
		FileInputStream fin = null;
		DataInputStream din = null;

		try {
			fin = new FileInputStream(file);
			din = new DataInputStream(fin);
			int reg = din.readInt();
			int mark1 = din.readInt();
			int mark2 = din.readInt();
			int mark3 = din.readInt();
			double fee = din.readDouble();
			String nam = din.readLine();
			
			String gend = din.readLine();
			int total=mark1+mark2+mark3;
			
			

		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}
		
		
		finally{
			try {
				din.close();
				fin.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}

	}

}
