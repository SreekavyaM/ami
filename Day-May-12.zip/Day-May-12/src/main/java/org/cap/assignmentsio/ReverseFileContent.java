package org.cap.assignmentsio;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReverseFileContent {
	public static void main(String[] args) {
		File file = new File("D:\\MyJava\\Workspace\\Day-May-12\\src\\main\\resources\\sourcefile.txt");
		File filenew = new File("D:\\MyJava\\Workspace\\Day-May-12\\src\\main\\resources\\Reverse.txt");

		FileReader fileReader = null;
		FileWriter fileWriter = null;
		String str = "";

		try {
			fileReader = new FileReader(file);
			fileWriter = new FileWriter(filenew);
			long fsize = file.length();
			while (fsize > 0) {
				int ch = fileReader.read();
				str += (char) ch;
				fsize--;
			}

			System.out.println(str);
			String reverse = "";
			for (int i = str.length() - 1; i >= 0; i--) {
				reverse = reverse + str.charAt(i);

			}
			System.out.println(reverse);
			fileWriter.write(reverse);
		} catch (FileNotFoundException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

		finally {
			try {
				fileReader.close();
				fileWriter.close();
			} catch (IOException e) {

				e.printStackTrace();
			}

		}

	}

}
