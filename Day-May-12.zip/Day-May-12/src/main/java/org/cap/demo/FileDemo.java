package org.cap.demo;

import java.io.File;
import java.io.IOException;

public class FileDemo {
	public static void main(String[] args) {
		File file = new File("D:\\MyJava\\Workspace\\Day-May-12\\src\\main\\resources\\sample.txt");
		if (file.isFile())
		{
			System.out.println("file...");
			System.out.println(file.length()+"bytes");
			System.out.println("is readable-"+file.canRead());
			System.out.println("is writtable-"+file.canWrite());
			System.out.println("is executable-"+file.canExecute());
			System.out.println(file.getAbsolutePath());
		
		}
			else if (file.isDirectory()) {
			System.out.println("its directory");
			String[] filename=file.list();
			
			for(String str:filename)
				System.out.println(str);

		} else {
			System.out.println("file not exists..create");
			try {
				file.createNewFile();
			} catch (IOException e) {
				
				e.printStackTrace();
			}
		}

	}
}
