package org.cap.assignmentexc;

import java.util.Scanner;

public class Vehicle2 {
	
	int y;
	Scanner s1=new Scanner(System.in);

	public void getDirection()
	{
		System.out.println("Enter your driving direction");
		System.out.println("1.<------Left");
		System.out.println("2.------>Right");
		y=s1.nextInt();
	
		
	}

}
