package org.cap.assignmentexc;

public class ArrayBoundExc extends Throwable {
	
	public String getMessage()
	{
		return "Number should be less than 9";
	}

}
