package org.cap.assignmentexc;

public class MainDivideZero {
	public static void main(String[] args) {
		DivideByZero div = new DivideByZero();
		div.getNumbers();

		div.divide();
	}

}
