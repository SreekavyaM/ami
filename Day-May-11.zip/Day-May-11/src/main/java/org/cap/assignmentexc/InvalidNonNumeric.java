package org.cap.assignmentexc;

public class InvalidNonNumeric {
	public static void main(String[] args) {

		String str ="";
		

		try {
			for (int i = 0; i < str.length(); i++) {
				

				if (str.charAt(i) != '1' || str.charAt(i) != '2' || str.charAt(i) != '3' || str.charAt(i) != '4'
						|| str.charAt(i) != '5')

					throw new Non_numericClass();
				
				else{
					str=str+"";
				}

			}
			}

		 catch (Non_numericClass e) {
			System.out.println(e.getMessage());
		}
	}

}
