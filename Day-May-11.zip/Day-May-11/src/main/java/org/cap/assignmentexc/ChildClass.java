package org.cap.assignmentexc;

public class ChildClass extends ParentClass {
	public void test() throws ArithmeticException
	{
		System.out.println("running test in child");
	}

}
