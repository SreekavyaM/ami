package org.cap.assignmentexc;

public class AccountMain {
	public static void main(String[] args) {
		AccountExc acc1=new AccountExc();
		acc1.getDetails();
	}

}
