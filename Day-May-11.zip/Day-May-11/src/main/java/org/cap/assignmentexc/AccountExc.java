package org.cap.assignmentexc;

import java.util.Scanner;

public class AccountExc {
	int accountId;
	String accountName;
	String openingDate;
	double depositAmt;
	String accountType;
	double min_dep_amt;
	
	Scanner s1=new Scanner(System.in);
	public void getDetails()
	{
		System.out.println("Choose your account type");
		System.out.println("1.Saving account");
		System.out.println("2.Current account");
		System.out.println("3.Salary account");
		
		int opt=s1.nextInt();
		if(opt==1)
		{
			System.out.println("Enter amount to be deposited");
			min_dep_amt=s1.nextDouble();
			
				try {
					if(min_dep_amt<1000)
					throw new DepositamtExc();
					else
					{
						System.out.println("Successfully deposited");
					}
				} catch (DepositamtExc e) {
					System.out.println(e.getMessage1());
				}
		}
		else if(opt==2)
		{
			System.out.println("Enter amount to be deposited");
			min_dep_amt=s1.nextDouble();
			
				try {
					if(min_dep_amt<5000)
					throw new DepositamtExc();
					else
					{
						System.out.println("Successfully deposited");
					}
				} catch (DepositamtExc e) {
					System.out.println(e.getMessage2());
				}
			
		}
		else if (opt==3) {
			System.out.println("Enter amount to be deposited");
			min_dep_amt=s1.nextDouble();

			System.out.println("Successfully deposited");
					
				
			
		}
		
	}

}
