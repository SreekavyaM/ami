package org.cap.assignmentexc;

public class MainParent {
	public static void main(String[] args) {
		ParentClass pt=new ParentClass();
		pt.test();
		
	}

}
