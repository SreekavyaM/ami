package org.cap.assignmentexc;

import java.util.Scanner;

public class DivideByZero {
	int x;
	int y;
	int z;

	public void getNumbers() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first number:");
		x = sc.nextInt();

		System.out.println("Enter second number");
		y = sc.nextInt();

	}

	public int divide() {

		try {
			if (y == 0) {
				throw new InvalidDividebyZero();
			} else {
				z = x / y;
			}
			System.out.println("result is:" + z);
		} catch (InvalidDividebyZero e) {

			System.out.println(e.getMessage());
		}
		return z;

	}

}
