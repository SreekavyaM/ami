package org.cap.assignmentexc;

import java.util.Scanner;

public class ExceptClass extends Throwable {
	@Override
	public String getMessage() {
		
		return "Exception......";
	}
	
	public void calculte()
	{
		
	}
	
	public static void main(String[] args) {
		
	}

}
