package org.cap.assignmentexc;

import java.util.Scanner;

public class MainStudent {

	public static void main(String[] args) {
		Student st[] = new Student[10];
		st[0] = new Student(1, "Ramesh");
		st[1] = new Student(2, "suresh");
		st[2] = new Student(3, "soms");
		st[3] = new Student(4, "wiki");
		st[4] = new Student(5, "tom");
		st[5] = new Student(6, "kavya");
		st[6] = new Student(7, "soms");
		st[7] = new Student(8, "wiki");
		st[8] = new Student(9, "tom");
		st[9] = new Student(10, "kavya");
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter choice");
		int i = sc.nextInt();
		
		
		
	
			try {
				if(i>9)
				throw new ArrayBoundExc();
				else
				{
					System.out.println(st[i]);
				}
			} catch (ArrayBoundExc e) {
				
				System.out.println(e.getMessage());
			
			}
		
			
		

	}

}
