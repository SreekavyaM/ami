package org.cap.assignmentexc;

import org.cap.exception.AgeInvalidException;

public class ParentClass {
	int X,Y,Z;
	
	public void test() 
	{
	X=12;
	Y=0;
	Z=X/Y;
		System.out.println("Running test method");
	}

}
