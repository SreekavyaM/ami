package org.cap.assignmentexc;

public class InvalidDividebyZero extends Throwable {
	public String getMessage() {
		return "It is not possible to divide by zero..enter other number";
	}

}
