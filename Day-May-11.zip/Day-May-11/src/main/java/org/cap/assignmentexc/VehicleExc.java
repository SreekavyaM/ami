package org.cap.assignmentexc;

public class VehicleExc extends Throwable {
	@Override
	public String getMessage() {
		
		return "Both vehicles cannot be in same direction";
	}

}
