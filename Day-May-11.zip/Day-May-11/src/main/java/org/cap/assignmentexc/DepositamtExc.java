package org.cap.assignmentexc;

public class DepositamtExc extends Throwable {

	public String getMessage1() {

		return "Minimum balance for savings account is 1000";
	}

	public String getMessage2() {

		return "Minimum balance for current account is 5000";
	}

}
