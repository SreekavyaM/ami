package org.cap.assignmentexc;

public class MainVehicle {
	public static void main(String[] args) {
		Vehicle1 v1=new Vehicle1();
		Vehicle2 v2=new Vehicle2();
		v1.getDirection();
		v2.getDirection();
		
			try {
				if(v1.x==v2.y)
				throw new VehicleExc();
				
				else
				{
					System.out.println("Direction is ok");
				}
			} catch (VehicleExc e) {
				System.out.println(e.getMessage());
			}
	}

}
