package org.cap.assignmentexc;

public class Non_numericClass extends Exception {

	public String getMessage() {

		return "Enter numeric value only";

	}

}
