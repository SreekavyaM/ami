package org.cap.assignmentexc;

public class Student {
	private int rollnum;
	private String name;
	public Student(int rollnum, String name) {
		super();
		this.rollnum = rollnum;
		this.name = name;
	}
	public String toString()
	{
		return "Student[rollnum="+this.rollnum+" name="+this.name+"]";
	}
	

}
