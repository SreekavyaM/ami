package org.cap.exception;

import java.lang.annotation.Target;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;;

@Target(ElementType.METHOD)
@Retention(RetentionPolicy.CLASS)

public @interface Author {
	String authorname();

	String publishDate() default "12-mar-2009";

	double price();

}
