package org.cap.exception;

@BookDetails(bookname = "Sree", authorname = "kavya", price = 450.78)

public class MainAnnotClass {

	
	@BookDetails(bookname = "Sree", authorname = "kavya", price = 450.78)
	public void sample() {
		System.out.println("running sample");
	}

}
