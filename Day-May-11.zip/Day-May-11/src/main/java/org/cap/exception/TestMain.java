package org.cap.exception;

public class TestMain {
	private static int sal;

	public static void main(String[] args) {
		TestClass2 t = new TestClass2();
		
		t.getSalary();
		assert sal>=2000 :"error";
	}
}
