package org.cap.exception;

public class Book {

	String bookname;
	String authorname;

	String publisher;

	double price;

	
	

}
