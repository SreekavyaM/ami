package org.cap.exception;

public class TestClass {
	public static void main(String[] args) {
		int age = 12;
		try{
		if (age < 18)
			throw new AgeInvalidException();
		else
			System.out.println("Eligible to vote");
		}
		catch(AgeInvalidException e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("Execution continuous");
	}
}
