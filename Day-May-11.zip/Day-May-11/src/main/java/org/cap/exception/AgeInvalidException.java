package org.cap.exception;

public class AgeInvalidException extends RuntimeException{
public String getMessage()
{
	return "Error..Age should be greater than 18";
}
}
