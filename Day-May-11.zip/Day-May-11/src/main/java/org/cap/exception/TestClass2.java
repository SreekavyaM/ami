package org.cap.exception;

import java.util.Scanner;

public class TestClass2 {
	public void getSalary()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter salary");
		double sal=sc.nextDouble();
	}
	
	

}
