package org.cap.exception;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD,ElementType.TYPE})
@Retention(RetentionPolicy.CLASS)
public @interface BookDetails {
	
	
	String bookname();
	String authorname();

	String publisher() default "Oxford";

	double price();

}
