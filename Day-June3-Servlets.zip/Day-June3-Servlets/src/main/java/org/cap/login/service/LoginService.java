package org.cap.login.service;

import org.cap.login.pojo.Login;

public interface LoginService {
	
	public boolean isValidUser(Login login);

}
