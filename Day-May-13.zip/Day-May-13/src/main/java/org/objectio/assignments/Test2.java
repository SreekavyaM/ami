package org.objectio.assignments;

import java.util.Scanner;

public class Test2 {
	
	int accNo;
	String name;
	String type;
	String openDate;
	double amount;
	private Address address;
	AccountNew acc = null;
	Scanner s1 = new Scanner(System.in);

public void getDetailsOfacc()
{
System.out.println("Enter your accno" );
accNo = s1.nextInt();

System.out.println("Enter your name" );
name = s1.next();

System.out.println("Enter your type" );
type = s1.next();
System.out.println("Enter your open date" );
openDate = s1.next();
System.out.println("Enter your amount");
amount = s1.nextDouble();

acc=new AccountNew(accNo, name, type, openDate, amount, address);

}
}
