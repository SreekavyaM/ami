package org.objectio.assignments;

import java.util.Scanner;

public class AccountDAOImplementation implements AccountDAO{
	int accNo;
	String name;
	String type;
	String openDate;
	double amount;
	private Address address;
	AccountNew acc = null;
	Scanner s1 = new Scanner(System.in);

	public AccountNew createAccount() {
		System.out.println("Enetr your accno" + accNo);
		accNo = s1.nextInt();

		System.out.println("Enetr your name" + name);
		name = s1.next();

		System.out.println("Enetr your type" + type);
		type = s1.next();
		System.out.println("Enetr your open date" + openDate);
		openDate = s1.next();
		System.out.println("Enetr your amount" + amount);
		amount = s1.nextDouble();

		return new AccountNew(accNo, name, type, openDate, amount, address);

	}

	public AccountNew readAccount()

	{
		System.out.println("Enter account num");
		int acNo = s1.nextInt();

		if (acNo == accNo) {
			return new AccountNew(accNo, name, type, openDate, amount, address);
		} else
			return null;

	}

	public void updatAccount() {
		System.out.println("1-update name");

		System.out.println("2-update open date");

		System.out.println("3-update amount");
		int opt = s1.nextInt();
		if (opt == 1) {

		} else if (opt == 2) {

		} else if (opt == 3) {

		} else {
			System.out.println("Enter valid option");
		}

	}

	

	

	public void deleteAccount() {
		// TODO Auto-generated method stub
		
	}

	public void viewAccount() {
		// TODO Auto-generated method stub
		
	}

}
