package org.objectio.assignments;

import java.util.Scanner;

public class Testmain {
	
	public static void main(String[] args) {
		
		Test t=new Test();
		Test2 t2=new Test2();
		int n;
		Scanner s1=new Scanner(System.in);
		System.out.println("1.To create account");
		System.out.println("2.To read account");
		System.out.println("3.To Delete account");
		n=s1.nextInt();
		if(n==1)
		{
			t2.getDetailsOfacc();
			t.createAccount();
		}
		

	}

}
