package org.objectio.assignments;

public class UserInteraction {

}
