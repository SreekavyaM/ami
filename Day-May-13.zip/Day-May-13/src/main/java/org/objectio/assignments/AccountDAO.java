package org.objectio.assignments;

public interface AccountDAO {
	public AccountNew createAccount();

	public void updatAccount();

	public AccountNew readAccount();

	public void deleteAccount();

	public void viewAccount();

}
