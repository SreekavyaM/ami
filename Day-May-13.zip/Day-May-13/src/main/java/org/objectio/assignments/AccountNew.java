package org.objectio.assignments;

import java.io.Serializable;

public class AccountNew implements Serializable {
	private int accNo;
	private String name;
	private String type;
	private String openDate;
	private double amount;
	private Address address;
	
	
	
	Address add=new Address();
	
	public AccountNew()
	{
		
	}
	
	public AccountNew(int accNo, String name, String type, String openDate, double amount, Address address) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.type = type;
		this.openDate = openDate;
		this.amount = amount;
		this.address =add.getAddress();
	}

	public int getAccNo() {
		return accNo;
	}
	public void setAccNo(int accNo) {
		this.accNo = accNo;
	}
	@Override
	public String toString() {
		return "AccountNew [accNo=" + accNo + ", name=" + name + ", type=" + type + ", openDate=" + openDate + ", amount="
				+ amount + ", address=" + address + "]";
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getOpenDate() {
		return openDate;
	}
	public void setOpenDate(String openDate) {
		this.openDate = openDate;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
	
	

}
