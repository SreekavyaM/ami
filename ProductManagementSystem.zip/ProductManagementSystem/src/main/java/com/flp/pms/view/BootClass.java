package com.flp.pms.view;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductService;
import com.flp.pms.service.IProductServiceImp;

public class BootClass {
	public static void main(String[] args) {
		menuSelection();

	}

	public static void menuSelection() {
		UserInteraction userInteraction = new UserInteraction();
		IProductServiceImp iProductService = new IProductServiceImp();

		Scanner sc = new Scanner(System.in);
		for (;;) {
			System.out.println("1.Create Product" + "\n2.Modify Product" + "\n3.Remove Product"
					+ "\n4.View all Products" + "\n5.Search Product" + "\n6.Exit");
			System.out.println("Enter your choice");

			int choice = sc.nextInt();

			switch (choice) {

			case 1:
				Product product = userInteraction.addProduct(iProductService.getAllCategory(),
						iProductService.getAllSubCategory(), iProductService.getAllDiscounts(),
						iProductService.getAllSuppliers());

				iProductService.addProduct(product);
				System.out.println("Product is added successfully");
				break;
			case 2:
				Product product1 = iProductService.searchByproductId(userInteraction.getProductIdToUpdate());
				if (product1 != null) {
					System.out.println("1.Update product name" + "\n2.Update manufacturing date"
							+ "\n3.update expiry date" + "\n4.Update Category" + "\n5.Update max reatil price");
					System.out.println("Enter your choice");
					int opt = sc.nextInt();

					switch (opt) {
					case 1:
						iProductService.updateProductName(product1, userInteraction.updateProductName());
						break;
				
					case 2:	Date manufacturingDate = userInteraction.updateManufacturingDate();
						iProductService.updateManufacturingDate(product1, manufacturingDate);
						break;
					case 3:
						Date expiryDate = userInteraction.updateExpiryDate();
						iProductService.updateExpiryDate(product1, expiryDate);
						break;
					case 4:
						Category category = userInteraction.getCategory(iProductService.getAllCategory());
						int categoryid=category.getCategory_Id();
						iProductService.updateProductCategory(product1, categoryid);
						break;
					case 5:
						Double mrp = userInteraction.updateMaxRetailPrice();
						iProductService.updateMaxRetailPrice(product1, mrp);
						break;

					}

				}

				break;
			case 3:
				iProductService.deleteProduct(userInteraction.deleteProductDetails());
				break;
			case 4:
				// System.out.println(iProductService.getAllProducts());
				//System.out.println(iProductService.getAllProductList());
				
				System.out.println(iProductService.getAllProductList());

				break;

			case 5:
				System.out.println("1.By product name" + "\n2.By producer" + "\n3.By category" + "\n4.By sub category"
						+ "\n5.By rating");
				System.out.println("Enter your search option:");
				int option = sc.nextInt();
				switch (option) {
				case 1:
					iProductService.searchByproductname(userInteraction.searchByProductName());
					break;
				case 2:
					iProductService.searchBySupplier(userInteraction.searchBySupplier());
					break;
				case 3:
					iProductService.searchByCategory(userInteraction.searchByCategory());
					break;
				case 4:
					iProductService.searchBySubcategory(userInteraction.searchBySubcategory());
					break;
				case 5:
					iProductService.searchByRating(userInteraction.searchByRating());
					break;

				}

			}
		}
	}
}
