package com.flp.pms.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.flp.pms.dao.IProductDao;
import com.flp.pms.dao.ProductDaoImpJDBC;
import com.flp.pms.dao.ProductDaoImplForMap;
import com.flp.pms.domain.Category;
import com.flp.pms.domain.Discount;
import com.flp.pms.domain.Product;
import com.flp.pms.domain.SubCategory;
import com.flp.pms.domain.Supplier;

public class IProductServiceImp implements IProductService {

	//private IProductDao iProductDao = new ProductDaoImplForMap();
	
	IProductDao iProductDao=new ProductDaoImpJDBC();

	public List<Category> getAllCategory() {
		return iProductDao.getAllCategory();
	}

	public List<SubCategory> getAllSubCategory() {
		return iProductDao.getAllSubCategory();
	}

	public List<Discount> getAllDiscounts() {

return iProductDao.getAllDiscounts();
	}

	public List<Supplier> getAllSuppliers() {
		return iProductDao.getAllSuppliers();
	}

	public void addProduct(Product product) {
		/*Map<Integer, Product> maps = iProductDao.getAllProducts();
		boolean flag = false;
		Set<Integer> product_IDS = maps.keySet();
		int product_id_generated = generateProductId();

		// Generate unique Product Id
		if (!maps.isEmpty()) {
			do {

				product_id_generated = generateProductId();
				for (Integer product_Id : product_IDS) {
					if (product_Id == product_id_generated) {
						flag = true;
						break;
					}
				}
			} while (flag);

		}
		product.setProductId(product_id_generated);
*/
		iProductDao.addProduct(product);
	}

	public int generateProductId() {
		return (int) (Math.random() * 10000);
	}

	

	public void deleteProduct(int productId) {
		/*Map<Integer, Product> products = iProductDao.getAllProducts();
		Set<Integer> keys = products.keySet();
		for (int key : keys) {
			if (key == productId) {
				products.remove(key);
				System.out.println("Product is removed");

			} else {
				System.out.println("Enter valid product id");
			}

		}*/
	List<Product> products=	iProductDao.getAllProducts();
	for(Product product:products)
		if(product.getProductId()==productId)
			iProductDao.deleteProduct(productId);
	
		
		
	}

	public List<Product> getAllProductList() {
		
		return iProductDao.getAllProducts();

	}

	public void searchByproductname(String productname) {

		List<Product> product = getAllProductList();
		List<Product> product1=new ArrayList<>();
		for (Product products : product) 
			if (products.getProductName().equals(productname))
				product1.add(products);
				System.out.println(product1);
			
		 /*else {
				System.out.println("Product is not found");
			}*/
	}

	public void searchBySupplier(String supplierName) {

		List<Product> product = getAllProductList();
		List<Product> product1=new ArrayList<>();
		for (Product products : product) 
			if (products.getSupplier().getFirstName().equals(supplierName)) 
				product1.add(products);
				System.out.println(product1);
			 /*else {
				System.out.println("Product is not found");
			}*/
		
	}

	public void searchByCategory(String categoryName) {

		List<Product> product = getAllProductList();
		List<Product> product1=new ArrayList<>();
		for (Product products : product) 
			if (products.getCategory().getCategory_Name().equals(categoryName)) 
				product1.add(products);
				System.out.println(product1);
		/*else {
				System.out.println("Product is not found");
			}*/
		
	}

	public void searchBySubcategory(String supplierName) {

		List<Product> product = getAllProductList();
		List<Product> product1=new ArrayList<>();
		for (Product products : product) 
			if (products.getSubCategory().getSub_category_Name().equals(supplierName)) 
				product1.add(products);
				System.out.println(product1);
			/*else {
				System.out.println("Product is not found");
			
		}*/
	}

	public void searchByRating(float rating) {

		List<Product> product = getAllProductList();
		List<Product> product1=new ArrayList<>();
		for (Product products : product)
			if (products.getRating() == (rating)) 
				product1.add(products);
				System.out.println(product1);
		/*else {
				System.out.println("Product is not found");
			}*/
		
	}

	public Product searchByproductId(int pId) {
		Product newProduct = null;
		List<Product> product = getAllProductList();
		for (Product products : product) {
			if (products.getProductId() == (pId)) {
				newProduct = products;
			}

		}
		return newProduct;

	}
	
	
	/*public Map<Integer,Product> updateProductName(Product p,String name)
	{
		Map<Integer,Product> updatedMap=iProductDao.getAllProducts();
		p.setProductName(name);
		updatedMap.put(p.getProductId(),p);
		
		System.out.println("Successfully updated name");
		System.out.println(updatedMap);
		return updatedMap;
		
	}
	
	

	public Map<Integer,Product> updateProductCategory(Product p, Category c) {
		Map<Integer,Product> updatedMap=iProductDao.getAllProducts();
		p.setCategory(c);
		updatedMap.put(p.getProductId(), p);
		System.out.println("Successfully updated category");
		System.out.println(updatedMap);
		return updatedMap;

		
	}
	
	public Map<Integer,Product> updateManufacturingDate(Product p,Date date)
	{
		Map<Integer,Product> updatedMap=iProductDao.getAllProducts();
		p.setManufacturing_date(date);
		updatedMap.put(p.getProductId(),p);
		
		System.out.println("Successfully updated name");
		System.out.println(updatedMap);
		return updatedMap;
		
	}
	
	public Map<Integer,Product> updateExpiryDate(Product p,Date date)
	{
		Map<Integer,Product> updatedMap=iProductDao.getAllProducts();
		p.setExpiry_date(date);
		updatedMap.put(p.getProductId(),p);
		
		System.out.println("Successfully updated name");
		System.out.println(updatedMap);
		return updatedMap;
		
	}
	
	public Map<Integer,Product> updateMaxRetailPrice(Product p,double mrp)
	{
		Map<Integer,Product> updatedMap=iProductDao.getAllProducts();
		p.setMaxRetailPrice(mrp);
		updatedMap.put(p.getProductId(),p);
		
		System.out.println("Successfully updated name");
		System.out.println(updatedMap);
		return updatedMap;
		
	}*/
	
	
	public void updateProductName(Product p,String name)
	{
		iProductDao.updateProductName(p, name);
		
	}
	
	public void updateProductCategory(Product p, int c)
	{
		iProductDao.updateProductCategory(p, c);
		
	}
	public void updateManufacturingDate(Product p,Date date)
	{
		iProductDao.updateManufacturingDate(p, date);
		
	}
	public void updateExpiryDate(Product p,Date date)
	{
		iProductDao.updateExpiryDate( p, date);
		
	}
	public void updateMaxRetailPrice(Product p,double mrp)
	{
		iProductDao.updateMaxRetailPrice(p, mrp);
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
