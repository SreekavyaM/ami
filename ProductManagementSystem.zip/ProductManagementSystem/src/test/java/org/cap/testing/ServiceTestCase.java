package org.cap.testing;

import org.junit.BeforeClass;
import org.junit.Test;

import com.flp.pms.domain.Category;
import com.flp.pms.domain.Product;
import com.flp.pms.service.IProductServiceImp;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

public class ServiceTestCase {

	static IProductServiceImp pService;

	@BeforeClass
	public static void setUp() {
		pService = new IProductServiceImp();
	}

	@Test
	public void countAllCategories() {
		List<Category> categories = pService.getAllCategory();
		assertEquals(5, categories.size());
	}

	@Test
	public void countAllCategoriesWithAllOptions() {
		List<Category> categories = pService.getAllCategory();
		assertThat(categories.size(), allOf(is(5), instanceOf(Integer.class)));
	}

	
	@Test
	public void generateProductId() {
		assertNotNull(pService.generateProductId());
	}

	@Test
	public void getAllProductlist() {

		assertEquals(true, pService.getAllProductList().isEmpty());
	}

}
