package org.cap.testing;

import static org.junit.Assert.*;

import org.junit.BeforeClass;
import org.junit.Test;

import com.flp.pms.dao.ProductDaoImplForMap;

public class DaoTestCase {
	static ProductDaoImplForMap daoImp;

	@BeforeClass
	public static void setUp() {
		daoImp = new ProductDaoImplForMap();
	}

	@Test
	public void allCategoryIsEmpty() {
		assertEquals(false, daoImp.getAllCategory().isEmpty());
	}
	
	@Test
	public void allSubcategoryIsEmpty(){
		assertEquals(false, daoImp.getAllSubCategory().isEmpty());
	}
	
	@Test
	public void allSupplierIsEmpty(){
		assertEquals(false, daoImp.getAllSuppliers().isEmpty());
	}
	
	@Test
	public void allDiscountIsEmpty(){
		assertEquals(false, daoImp.getAllDiscounts().isEmpty());
	}
	
	@Test
	public void addProduct(){
		assertNotNull(daoImp.getAllProducts());
	}
	

}
