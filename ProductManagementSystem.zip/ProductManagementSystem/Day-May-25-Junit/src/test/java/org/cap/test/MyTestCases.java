package org.cap.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class MyTestCases {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
