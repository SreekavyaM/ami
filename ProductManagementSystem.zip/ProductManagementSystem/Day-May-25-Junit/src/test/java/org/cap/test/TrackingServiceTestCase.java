package org.cap.test;

import static org.junit.Assert.*;

import org.cap.trackingservice.TrackingService;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TrackingServiceTestCase {
	
	TrackingService service;
	
	@Before
	public void createServiceIntance(){
		System.out.println("TestCase Started");
		service=new TrackingService();
	}
	
	@After
	public void afterTestCase(){
		System.out.println("TestCase Over");
	}
	
	@BeforeClass
	public static void setUp(){
		System.out.println("Class loaded with supporting instance");
	}
	
	@AfterClass
	public static void tearDown(){
		System.out.println("Class object destroyed after completion!");
	}

	@Test
	public void whenIncreaseProductIncreaseTotal(){
		service.produceProduct(10);
		
		assertEquals(10, service.getTotal());
	}
	
	
	@Test
	public void whenDecreaseProductDecreaseTotal(){
		service.consumeProduct(5);
		
		assertEquals(0, service.getTotal());
	}
	
	@Test(timeout=50)
	public void testmyLoop(){
		
		
		assertEquals(6, service.myLoop());
	}
	
	

}
