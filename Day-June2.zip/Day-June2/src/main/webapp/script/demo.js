function showData(){
	
	var myTime=(function showTime(){
	var d=new Date();
	document.getElementById('divTime').innerHTML=d.toLocaleTimeString();
});
	setInterval(myTime,500);
	
}


/*
function show(){
	setInterval((function(){
		var d=new Date();
		document.getElementById('divTime').innerHTML=d.toLocaleTimeString();
	}), 500);

}
*/
