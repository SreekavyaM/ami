package org.cap.demo.threaddemo;

public class Product {
	private int qty=10;
	
	
	synchronized public void consumeProduct(int quantity){
		
		
		
		
		while(this.qty<quantity){
			System.out.println("Insufficient Quanity!Waiting for produced...");
			
				try {
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
	
		
		this.qty-=quantity;
		System.out.println("Prodcut Consumed. Updated Quantity=" + this.qty);
		
		
	}
	
	
	synchronized public void produceProduct(int qunatity){
		System.out.println("Producer Started!");
		this.qty+=qunatity;
		System.out.println("Prodcut Produced. Updated Quantity=" + this.qty);
		
		notifyAll();
		
	}
	
	

}
