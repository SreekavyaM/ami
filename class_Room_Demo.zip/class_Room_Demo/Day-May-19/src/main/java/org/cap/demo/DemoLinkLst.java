package org.cap.demo;

import java.util.LinkedList;
import java.util.List;

public class DemoLinkLst {

	public static void main(String[] args) {
		
		LinkedList<String> mylst=new LinkedList<>();
		mylst.add("tom");
		mylst.add("jerry");
		
		mylst.add("tom");
		
		mylst.add("jack");
		
		mylst.add("sam");
		mylst.add("tom");
		mylst.add(null);
		mylst.add(null);
		
		
		System.out.println(mylst);
		

		

	}

}
