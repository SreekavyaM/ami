DELIMITER $$

CREATE
   
    PROCEDURE `capdb`.`listEmployees`(OUT ans VARCHAR(100))
	BEGIN
	DECLARE msg VARCHAR(30) DEFAULT ' ';
	DECLARE fname VARCHAR(50);
	DECLARE lname VARCHAR(50);

	DECLARE finished INT DEFAULT 0;
	DECLARE  emp CURSOR FOR SELECT firstName,lastName FROM employee WHERE salary>10000;
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET finished = 1;
	
	OPEN emp;
	
	l1:WHILE finished=0 DO 
	
	FETCH emp INTO fname,lname;
	
	SET msg=CONCAT(msg ,';',fname,' ' ,lname);
	
	END WHILE;
	

	CLOSE emp;
	SET ans=msg;
  

    END$$

DELIMITER ;