package org.cap.mytag;

import java.io.IOException;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

public class MyDateTagHandler extends SimpleTagSupport{
	
	private String myFormat;
	
	
	

	public void setMyFormat(String myFormat) {
		this.myFormat = myFormat;
	}




	@Override
	public void doTag() throws JspException, IOException {
		JspWriter out=getJspContext().getOut();
		Date currDate=new Date();
		
		StringWriter str=new StringWriter();
		getJspBody().invoke(str);
		
		if(myFormat==null)
			out.println( str + "  <b>"+currDate +"</b>");
		else{
			SimpleDateFormat dtFormat=new SimpleDateFormat(myFormat);
			String chgDate=dtFormat.format(currDate);
			out.println( str + "  <b>"+chgDate +"</b>");
		}
	}
	
	

}
