package org.cap.demo;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		UserInteraction interaction=new UserInteraction();
		Employee emp= interaction.getEmployee();
		
		System.out.println(emp);
		
	}

}
