package org.cap.demo.exp;




public class MyClass {

	public static void main(String[] args) {

		
		/*Integer num=null;
		
		int num1=100;
		try{
		int ans=num+num1;
		System.out.println("Answer:" + ans);
		System.exit(0);
		}catch(NullPointerException ex){
		
			System.out.println("Error Msg:"+ex.getMessage());
			
		}finally{
			
			System.out.println("Finally Block-Here!");
		}
		
		System.out.println("Program Completed!");*/
		 
	}

}



