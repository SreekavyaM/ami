package org.cap.demo;

import java.util.Date;
import java.util.Scanner;

public class UserInteraction {
	
	public Employee getEmployee(){
		
		Employee employee=new Employee();
		int employeeId;
		boolean flag=false;
		String eid,empKinId;
		Scanner sc=new Scanner(System.in);
		
		
		//Validate Employee Id
		do{
		System.out.println("Enter Employee Id:");
		eid=sc.next();
		flag=Validate.isValidEmployeeId(eid);
			if(!flag)
				System.out.println("INvalid EmployeeId! ID should be 5 digit!");
		
		}while(!flag);

		employee.setEmpId(Integer.parseInt(eid));
		
		
				//Validate Employee KinId
				do{
				System.out.println("Enter Employee KinId:");
				empKinId=sc.next();
				flag=Validate.isValidKinId(empKinId);
					if(!flag)
						System.out.println("INvalid KinId!");
				
				}while(!flag);

				
				employee.setKinId(empKinId);
				
		
				System.out.println("Enter Date of Birth:");
				employee.setEmpDob(getDateValue());
				
				System.out.println("Enter Date of Joining:");
				employee.setEmpDoj(getDateValue());
		
				
		return employee;
	}

	
	public Date getDateValue(){
		String empDob;
		Scanner sc=new Scanner(System.in);
		boolean flag=false;
		
		do{
		
		empDob=sc.next();
		flag=Validate.isValidDate(empDob);
			if(!flag)
				System.out.println("Invalid Date Format! (dd-MMM-yyyy)");
		
		}while(!flag);
		
		
		Date empdb=new Date(empDob);
		
		return empdb;
	}
	
	
	
	
	
	
	
	
	
	
}
