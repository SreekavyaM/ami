package org.cap.demo;

public class Validate {
	
	public static boolean isValidEmployeeId(String empId){
		return empId.matches("\\d{5}");
	}
	
	public static boolean isValidKinId(String kinid){
		return kinid.matches("\\d{5}_(FS|TS|IN|fs|ts|in)");
	}
	
	
	public static boolean isValidDate(String empDob){
		return empDob.matches("[0-3][0-9]-(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)-"
				+ "[12][7890]\\d{2}");
	}

}
