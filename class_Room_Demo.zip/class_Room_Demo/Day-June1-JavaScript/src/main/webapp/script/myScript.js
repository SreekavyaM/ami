function sayMsg(){
		alert('Hello! Welcome To JavaScript');
	}

function empValidation(){
	var flag=false;
	var ename=empForm.empName.value;
	var empPwd=empForm.empPwd.value;
	var len=empPwd.length;

	if(ename==''){
		
		document.getElementById('empNameMsg').innerHTML='*Please enter Employee name.';
	
	}
		else{
		document.getElementById('empNameMsg').innerHTML='';
		
		if(len<6 || len>15){
			
			document.getElementById('empPwdMsg').innerHTML='*Password chars must be between 6 to 15.';
		}else
			{
			document.getElementById('empPwdMsg').innerHTML='';
			flag=true;
			}
		
		
	}

	return flag;
}