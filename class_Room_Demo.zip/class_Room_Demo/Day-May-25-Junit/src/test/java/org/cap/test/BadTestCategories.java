package org.cap.test;

public interface BadTestCategories {

}
