package org.cap.test;

import static org.junit.Assert.*;

import org.cap.trackingservice.InvalidGoalException;
import org.cap.trackingservice.TrackingService;
import org.junit.Rule;
import org.junit.Test;
import org.junit.internal.runners.statements.ExpectException;
import org.junit.rules.ExpectedException;
import org.junit.rules.Timeout;

import static org.hamcrest.CoreMatchers.*;

public class MyTest {

	private TrackingService service=new TrackingService();
	
	@Rule
	public ExpectedException expectedException=ExpectedException.none();
	@Test
	public void checkInvalidGoalException() throws InvalidGoalException{
		
		expectedException.expect(InvalidGoalException.class);
		//expectedException.expectMessage("Goal should be positive!");
		expectedException.expectMessage(containsString("Goal"));
		service.setGoal(-56);
	}
	
	@Rule
	public Timeout timeout=new Timeout(200);
	@Test
	public void myLoop(){
		long sum=0;
		for(long i=0;i<1000000000;i++)
			sum+=i;
	}
	

}
