package org.cap.trackingservice;

public class InvalidGoalException extends Exception {

	public InvalidGoalException(String msg){
		super(msg);
	}
	
	/*@Override
	public String getMessage(){
		return "Goal should be greater than zero!";
	}*/
}
