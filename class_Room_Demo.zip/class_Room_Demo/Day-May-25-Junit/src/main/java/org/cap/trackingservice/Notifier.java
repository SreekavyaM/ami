package org.cap.trackingservice;

public interface Notifier {
	
	boolean send(String msg);

}
