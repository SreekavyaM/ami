DELIMITER $$

CREATE
   
    FUNCTION `capdb`.`findMax`(num1 INT,num2 INT,num3 INT)
    RETURNS INT
    
    BEGIN
	DECLARE ans INT;
	IF num1>num2 AND num1>num3 THEN
		SET ans=num1;
	ELSEIF num2>num3 THEN
		SET ans=num2;
	ELSE
		SET ans=num3;
	END IF;
	RETURN ans;

    END$$

DELIMITER ;