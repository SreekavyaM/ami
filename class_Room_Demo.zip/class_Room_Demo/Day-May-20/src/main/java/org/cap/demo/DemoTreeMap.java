package org.cap.demo;

import java.util.TreeMap;

public class DemoTreeMap {

	public static void main(String[] args) {
		TreeMap<Integer, String> map=new TreeMap<Integer, String>();
		map.put(1, "Tom");
		map.put(11, "Tom");
		map.put(1, "jas");
		//map.put(13,null);
		map.put(167, "Kamal");
		map.put(3, "Singh");
		/*map.put(null, "null");
		map.put(null, null);*/
		
		System.out.println(map);
		
	}

}
