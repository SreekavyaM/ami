package org.cap.demo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.TreeSet;

public class MainClass {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		Employee emp1=new Employee(1, "tom","jerry" , 23000);
		Employee emp2=new Employee(12, "kamal","singh" , 2889);
		Employee emp3=new Employee(3, "ram","singh" , 1200);
		Employee emp4=new Employee(4, "annie","tom" , 4566);
		Employee emp5=new Employee(8, "emi","jas" , 23003);
		Employee emp6=new Employee(4, "annie","tom" , 4566);
		Employee emp7=new Employee(4, "annie","tom" , 4566);
		Employee emp8=new Employee(12, "kamal","singh" , 2889);
		Employee emp9=new Employee(12, "kamal","singh" , 2889);
		
		HashSet<Employee> employees=new HashSet<Employee>();
		//LinkedHashSet<Employee> employees=new LinkedHashSet<Employee>();
		//TreeSet<Employee> employees=new TreeSet<Employee>();
		List<Employee> lst=new ArrayList<Employee>();
		
		
		employees.add(emp1);
		employees.add(emp2);
		employees.add(emp3);
		employees.add(emp4);
		employees.add(emp5);
		employees.add(emp6);
		employees.add(emp7);
		employees.add(emp8);
		employees.add(emp9);
		
		//lst=(List<Employee>) employees;
		
		for(Employee emp:employees)
			lst.add(emp);
	
		Collections.sort(lst,new SortByEmpId());
		
		Iterator<Employee> it= lst.iterator();
		while(it.hasNext())
			System.out.println(it.next());
		

	}

}
