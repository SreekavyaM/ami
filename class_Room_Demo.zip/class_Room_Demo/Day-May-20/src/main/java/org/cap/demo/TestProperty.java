package org.cap.demo;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class TestProperty {

	public static void main(String[] args) {
		try {
			FileReader reader=new FileReader("D:\\vidavid\\Training\\2016\\Trained_FLP_Chennai_2_May_2016_to_30_June_2016\\Trained_FLP\\Demo\\class_Room_Demo\\Day-May-20\\src\\main\\resources\\message.properties");
			
			Properties p=new Properties();
			p.load(reader);
			
			System.out.println(p.getProperty("greetings"));
			System.out.println(p.getProperty("user"));
			System.out.println(p.getProperty("password"));
			
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		

	}

}
