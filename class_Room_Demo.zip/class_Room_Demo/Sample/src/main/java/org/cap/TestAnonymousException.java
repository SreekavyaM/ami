package org.cap;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class TestAnonymousException {
	
    public static void main(String[] args) {
    	/* Object [] myObjects = {
    			 new Integer(12),
    			 new String("foo"),
    			 new Integer(5),
    			 new Boolean(true)
    			 };
    			 Arrays.sort(myObjects);
    			 for( int i=0; i<myObjects.length; i++) {
    			 System.out.print(myObjects[i].toString());
    			 System.out.print(" ");
    			 }*/
    	
    	//ifTest(true);
    	
    	 int a =0;
         int i=0;
        // TestAnonymousException t =new TestAnonymousException();
         for(int j=0;j<2;j++){
              for(i=0;i<4;i++){
                   a=j;
              }
         System.out.println(i);
         }
    }
    
    public static void ifTest(boolean flag)
    {
    if (flag) //1
    if (flag) //2
    if (flag) //3
    System.out.println("False True");
    else //4
    System.out.println("True False");
    else //5
    System.out.println("True True");
    else //6
    System.out.println("False False");
    }
    
}
