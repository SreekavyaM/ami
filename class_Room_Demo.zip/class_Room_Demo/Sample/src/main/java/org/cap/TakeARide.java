package org.cap;

public class TakeARide {
    public static void main(String args[]) {
         Car c = new Car();
         Vehicle v = c;
         System.out.println("|" + v.getModelName() + "|" + c.getModelName() + "|" + v.getRegNo() + "|" + c.getRegNo() + "|");
    }
}