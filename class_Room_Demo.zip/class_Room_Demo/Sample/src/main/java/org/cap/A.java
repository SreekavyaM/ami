package org.cap;

class A extends Thread {
	  String[] sa;
	  public A(String[] sa) {this.sa = sa;}
	  public void run() {
	    synchronized (sa) {System.out.print(sa[0] + sa[1] + sa[2]);}
	}}