package org.cap;

class Vehicle {
    static public String getModelName() { return "Volvo"; }
    public long getRegNo() { return 12345; }
}