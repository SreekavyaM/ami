package org.cap;


	abstract class Demo extends RuntimeException { }
	