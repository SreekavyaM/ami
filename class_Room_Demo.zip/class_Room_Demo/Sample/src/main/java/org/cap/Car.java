package org.cap;

class Car extends Vehicle {
    static public String getModelName() { return "Toyota"; }
    public long getRegNo() { return 54321; }
}