package org.cap;

public class DoCompare1 {

	/* public static void main(String[] args) {
	 // TODO Auto-generated method stub
	
	 String str = new DoCompare1().getTypeOfDay("Monday");
	  System.out.println(str);
		 
		 boolean oldTruth = true;
         Boolean newTruthOne = new Boolean("true");
         Boolean newTruthTwo = new Boolean("true");
         System.out.println((oldTruth == newTruthOne) ? "new truth one" : "old truth");
         System.out.println((newTruthOne == newTruthTwo) ? "new truth two" : "new truth one");
	
	}
	
	
		 public String getTypeOfDay(String dayOfWeekArg) {
	  String typeOfDay;
		   switch ( dayOfWeekArg ) {
	     case "Monday":
	        typeOfDay = "Start of work week";
		        break;
		    case "Tuesday":
	     case "Wednesday":
	     case "Thursday":
		       typeOfDay = "Midweek";
		        break;
		    case "Friday":
		      typeOfDay = "End of work week";
		      break;
		    case "Saturday":
		    case "Sunday":
		       typeOfDay = "Weekend";
	      break;
		     default:
		      throw new IllegalArgumentException("Invalid day of the week: " + dayOfWeekArg);
		   }
	   return typeOfDay;
	 }*/
	
	/*int x;                                    // 1
	  public static void main(String[] args) {  // 2
	    int y = 0;                              // 3
	    System.out.print(x+"");                // 4
	    System.out.print(y);                    // 5
	  }*/

}
