package org.capgemini.demo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

public class DemoBatch {

	public static void main(String[] args) {
		
		
		Connection conn=null;
		try {
			
			//Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish Connection
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","admin");
			
			boolean flag=false;
			conn.setAutoCommit(false);
			
			Statement stmt=conn.createStatement();
			
			stmt.addBatch("insert into employee values(333,'aaa','aaaa',32233,2,'aaa@gmail.com')");
			stmt.addBatch("insert into employee values(14,'bbb','aaaa',4343,2,'bbb@gmail.com')");
			
			Savepoint s1=conn.setSavepoint();
			
			stmt.addBatch("insert into employee values(17,'cccc','aaaa',6767,1,'cccc@gmail.com')");
			stmt.addBatch("insert into employee values(22,'asdd','aaaa',65555,2,'asdd@gmail.com')");
			stmt.addBatch("insert into employee values(1988,'azzzz','aaaa',32233,1,'azzzz@gmail.com')");
			stmt.addBatch("insert into employee values(1777,'eeee','aaaa',32233,2,'rrr@gmail.com')");
			
			
			int[] result=stmt.executeBatch();
			
			Savepoint s2=conn.setSavepoint();
			for(int i:result){
				if(i>0)
					flag=true;
				else{
					flag=false;
					break;
				}
				System.out.println(i);
			}
			
			if(flag)
				conn.commit();
			else
				conn.rollback(s2);
			
		
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
