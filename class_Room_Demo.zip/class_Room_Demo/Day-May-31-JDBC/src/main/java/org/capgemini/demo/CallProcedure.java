package org.capgemini.demo;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;

public class CallProcedure {

	public static void main(String[] args) {
		Connection conn=null;
		try {
			
			//Load Driver Class
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish Connection
			conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/capdb","root","admin");
		
		
		CallableStatement proCall=conn.prepareCall("{call findEmployee(?,?)}");
		proCall.setInt(1, 17);
		proCall.registerOutParameter(2, Types.VARCHAR);
		
		proCall.execute();
		
		String empName=proCall.getString(2);
			
		System.out.println("Hello! "+empName);
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

}
