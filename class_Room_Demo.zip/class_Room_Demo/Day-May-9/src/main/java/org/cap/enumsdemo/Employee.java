package org.cap.enumsdemo;

public class Employee {
	
	private int empId;
	private String empName;
	private double salary;
	private Month empJoin_month;
	
	
	public Employee(){}
	
	public Employee(int empId, String empName, double salary, Month empJoin_month) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.salary = salary;
		this.empJoin_month = empJoin_month;
	}
	
	
	public void printEmployee(){
		System.out.println("\nId: " + empId +
				"\nNAme:" + empName
				+"\nSalary :" + salary +
				"\nJoining Month :" + empJoin_month);
	}
	

}
