package org.cap.enumsdemo;

enum CustomerType{
	SILVER(0,200), GOLD(201,500), DIAMOND(501,800), PLATINUM(801,1500);
	
	private int minValue;
	private int maxValue;
	
	CustomerType(int minValue,int maxValue){
		this.maxValue=maxValue;
		this.minValue=minValue;
	}
	
	public int getMinValue(){
		return this.minValue;
	}
	
	public int getMaxValue(){
		return this.maxValue;
	}
	


}

public class Customer {

	
	

	private int custId=1001;
	private String custName="Tom";
	private double regFees=23000;
	private CustomerType custType=CustomerType.SILVER;
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
