package org.capgemini.demo;

public class Circle implements RectangleOnCorcle {

	public void draw() {
		// TODO Auto-generated method stub
		
	}

	public void getPoints() {
		// TODO Auto-generated method stub
		
	}

	public void getColor() {
		// TODO Auto-generated method stub
		
	}

	public void fillColor() {
		// TODO Auto-generated method stub
		
	}

	public void moveShape() {
		// TODO Auto-generated method stub
		
	}

	public void drawRect_Circle() {
		// TODO Auto-generated method stub
		
	}

}
