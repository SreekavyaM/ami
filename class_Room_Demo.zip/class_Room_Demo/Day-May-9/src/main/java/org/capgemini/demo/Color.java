package org.capgemini.demo;

public interface Color {
	
	public void getColor();
	public void fillColor();

}
