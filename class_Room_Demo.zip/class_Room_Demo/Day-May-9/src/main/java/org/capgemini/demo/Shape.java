package org.capgemini.demo;

public interface Shape {
	
	public static final float PI=3.14f;
	
	void draw();
	public void getPoints();

}
