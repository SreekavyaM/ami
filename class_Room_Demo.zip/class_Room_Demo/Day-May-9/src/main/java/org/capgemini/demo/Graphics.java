package org.capgemini.demo;

public interface Graphics {
	public void moveShape();
}
