package org.capgemini.demo;

public class TestClass {

	public static void main(String[] args) {
		
		Shape shape=new Shape() {
			
			public void getPoints() {
				System.out.println("Shape Points");
			}
			
			public void draw() {
				System.out.println("Draw Shape");
				
			}
		};
		

		shape.draw();
		shape.getPoints();
		
	}

}
