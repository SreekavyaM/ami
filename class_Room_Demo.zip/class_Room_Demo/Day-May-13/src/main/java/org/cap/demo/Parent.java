package org.cap.demo;

public class Parent {
	
	public  Parent method(){
		
		return null;
	}

}
