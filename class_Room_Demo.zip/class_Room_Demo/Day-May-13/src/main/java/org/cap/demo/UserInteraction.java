package org.cap.demo;

import java.util.Scanner;

public class UserInteraction {

	
	public Employee getEmployee(){
		int empId;
		String fName;
		String lName;
		double salary;
		Scanner sc=new Scanner(System.in);
		
		
		
		System.out.println("Enter EmpId:");
		empId=sc.nextInt();
		System.out.println("Enter FirstName:");
		fName=sc.next();
		System.out.println("Enter LastName:");
		lName=sc.next();
		System.out.println("Enter Salary:");
		salary=sc.nextDouble();
		System.out.println("Enter Employee Password:");
		String empPassword=sc.next();
		
		
		return new Employee(empId, fName, lName, salary,empPassword);
	}
}
