package org.capgemini.test;

public class Child_Class extends Abs_Classs{

	
	public Child_Class(){
		System.out.println("Child Constrcutor");
	}
	@Override
	public void info() {
		
		System.out.println("Child -info");
	}

	
public void child_Method() {
		
		System.out.println("child_Method");
	}
}
