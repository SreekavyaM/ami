package org.capgemini.demo;

public class Sample {
	public static void show(){
		
		System.out.println("Show Method - Sample");
	}
}
