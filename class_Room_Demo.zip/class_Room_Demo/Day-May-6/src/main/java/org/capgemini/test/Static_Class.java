package org.capgemini.test;

 public class Static_Class {
	
	String name="Tom";
	private static int count=100;
	
	static class Inner_Class{
		int num=900;
		
		public void show( int count){
			
			
			count=300;
			System.out.println("Inner Class Method");
			System.out.println("Number:" + num);
			System.out.println("Count:" + count);
			
			Static_Class obj=new Static_Class();
			System.out.println("Name:" + obj.name);
			
		}
	}

}
