package org.cap.assignments;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class DemoLinkedList {
	public static void main(String[] args) {

		LinkedList<String> link1 = new LinkedList<>();

		link1.add("Sree");

		link1.add("Sreekavya");
		link1.add("Lahari");
		link1.add("Kalitha");
		link1.add("Divya");
		link1.add("Tom");
		link1.add("Jerry");

		link1.add("Kalitha");

		link1.addFirst("Gagan");
		link1.addLast("kavyaa");
		
		
		Iterator<String> itr1=link1.iterator();
		
		
		
		while(itr1.hasNext())
		{
			System.out.print(itr1.next());
		}
			
		
		System.out.println(link1.getFirst());
		System.out.println(link1.getLast());
		 System.out.println(link1.offerFirst("soumya"));
		System.out.println(link1.offerLast("remya"));
		System.out.println(link1.offer("raghu"));
		
		
		
		
		System.out.println(link1.peek());

		System.out.println(link1.peekFirst());
		System.out.println(link1.peekLast());
		System.out.println(link1.poll());
		System.out.println(link1.pollFirst());
		System.out.println(link1.pollLast());
		System.out.println(link1.pop());
		link1.push("Lahari");
		
		
		while(itr1.hasNext())
		{
			System.out.print(itr1.next());
		}
			

		System.out.println(link1.removeFirstOccurrence("Divya"));
		System.out.println(link1.removeLast());
		System.out.println(link1.removeLastOccurrence("Kalitha"));

		System.out.println(link1.retainAll(link1));
		
	
	
	while(itr1.hasNext())
	{
		System.out.print(itr1.next());
	}
		

	}

}
