package org.cap.assignments;

import java.util.Vector;

public class DemoVector {

	public static void main(String[] args) {

		Vector<String> v1=new Vector<>(20,10);//20 initial size,it will increase by 10
		
		v1.add("Sreekavya");
		v1.add("Lahari");
		v1.add("Kalitha");
		v1.add("Divya");
		v1.add("Tom");
		v1.add("Jerry");
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
