package org.cap.assignments;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.ListIterator;

public class SampleCollection {
	public static void main(String[] args) {
		
	
	
	ArrayList<Integer> list1=new ArrayList<>();
	
	list1.add(10);
	list1.add(20);
	list1.add(30);
	list1.add(40);
	
	
	
	ArrayList<Integer> list2=new ArrayList<>();
	
	list2.addAll(list1);
	list2.add(50);
	
	System.out.println(list2.contains(40));
	System.out.println(list2.containsAll(list1));
	list1.ensureCapacity(1);
	System.out.println(list1.get(0));
	System.out.println(list1.get(3));
	System.out.println(list2.get(4));
	
	System.out.println(list2.indexOf(50));
	//System.out.println(list2.indexOf(list1)); it will print -1
	
	
	System.out.println(list2.isEmpty());
	
	ArrayList<Integer> list3=new ArrayList<>();
	System.out.println(list3.isEmpty());
	
	
	Iterator<Integer> itr=list2.iterator();
	while(itr.hasNext())
	{
		System.out.println(itr.next());
	}
	
	System.out.println(list2.lastIndexOf(50));
	//System.out.println(list2.lastIndexOf(list1)); it will print -1
	
	
	ListIterator<Integer> lItr=list1.listIterator();
	System.out.println(list2.remove(4));
	System.out.println(list2.removeAll(list1));
	System.out.println(list1.set(0, 20));
	
	System.out.println(list1.set(3, 60));
	System.out.println(list1.size());
	
	System.out.println(list1.subList(0, 3));
	int a[];
	System.out.println(list1.toArray());
	
	list1.trimToSize();
	Collections.sort(list1);
	
	
	
	
	
	
	
	
	
	
	
	
	}
}
